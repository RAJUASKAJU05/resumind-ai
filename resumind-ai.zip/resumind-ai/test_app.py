import os, io, tempfile
os.environ["DB_PATH"] = tempfile.mktemp(suffix=".db")
from fastapi.testclient import TestClient
import docx, app as A
c = TestClient(A.app)
RESUME = ["Asha Patil","asha@example.com  +91 98765 43210  github.com/asha","Summary","Diploma student in electronics and computer engineering.","Skills","Python, SQL, Git, Docker, Linux, React, REST API, PLC",
 "Education","Diploma in Electronics and Computer Engineering","Experience","Built a PLC monitoring tool that reduced manual checks by 30%","Automated data entry reports using Python scripts","Projects","Developed a resume analyzer using FastAPI and React"]
def mk():
    d = docx.Document()
    for l in RESUME * 3: d.add_paragraph(l)
    b = io.BytesIO(); d.save(b); return b.getvalue()
def test_flow():
    assert c.post("/api/resumes/upload", files={"file": ("a.docx", mk())}).status_code == 401
    r = c.post("/api/auth/register", json={"name": "A", "email": "a@x.com", "password": "password1"}); assert r.status_code == 201
    assert c.post("/api/auth/register", json={"name": "A", "email": "a@x.com", "password": "password1"}).status_code == 409
    assert c.post("/api/resumes/upload", files={"file": ("a.txt", b"hello")}).status_code == 400
    assert c.post("/api/resumes/upload", files={"file": ("a.docx", b"PKnotreal")}).status_code == 422
    r = c.post("/api/resumes/upload", files={"file": ("a.docx", mk())}); assert r.status_code == 201, r.text
    rid = r.json()["id"]; d = c.get(f"/api/resumes/{rid}").json()
    assert "python" in d["parsed"]["skills"] and d["parsed"]["email"] == "asha@example.com" and 0 < d["analysis"]["ats_score"] <= 100
    j = c.post("/api/jobs", json={"title": "Dev", "description": "Looking for Python, SQL, AWS and Kubernetes experience with Docker and Git."}).json()["id"]
    m = c.post(f"/api/jobs/{j}/match?resume_id={rid}").json()
    assert "aws" in m["missing_skills"] and "python" in m["matching_skills"]
    assert c.post("/api/ai/improve", json={"text": "Worked on Python"}).status_code in (200, 503)
    c2 = TestClient(A.app); c2.post("/api/auth/register", json={"name": "B", "email": "b@x.com", "password": "password2"})
    assert c2.get(f"/api/resumes/{rid}").status_code == 404  # authorization
    assert c.delete(f"/api/resumes/{rid}").status_code == 204 and c.get(f"/api/resumes/{rid}").status_code == 404

def test_ocr_image_and_extras():
    from PIL import Image, ImageDraw, ImageFont
    img = Image.new("RGB", (1400, 900), "white"); d = ImageDraw.Draw(img)
    f = ImageFont.load_default(size=34)
    y = 30
    for l in ["Ravi Kumar", "ravi@example.com 9876543210", "Skills", "Python SQL Git Docker Linux React", "Education", "Diploma in Computer Engineering", "Experience", "Built a Python tool for automated reports", "Projects", "Developed a web app using React and FastAPI"]:
        d.text((40, y), l, fill="black", font=f); y += 70
    b = io.BytesIO(); img.save(b, "PNG")
    c.post("/api/auth/register", json={"name": "O", "email": "o@x.com", "password": "password1"})
    r = c.post("/api/resumes/upload", files={"file": ("scan.png", b.getvalue())}); assert r.status_code == 201, r.text
    d = c.get(f"/api/resumes/{r.json()['id']}").json()
    assert "python" in d["parsed"]["skills"]
    rid = r.json()["id"]; dup = c.post(f"/api/resumes/{rid}/duplicate").json()["id"]
    cm = c.get(f"/api/resumes/{rid}/compare/{dup}").json(); assert cm["only_in_a"] == [] and cm["shared"]
    assert c.get("/api/ai/history").status_code == 200
    assert c.post("/api/auth/reset-password", json={"email": "o@x.com", "new_password": "newpass123", "code": "x"}).status_code == 403
    assert c.delete("/api/auth/account").status_code == 204 and c.get("/api/auth/me").status_code == 401


def test_flow_features():
    k = TestClient(A.app); k.post("/api/auth/register", json={"name": "F", "email": "f@x.com", "password": "password1"})
    assert [s["done"] for s in k.get("/api/flow").json()] == [False] * 7
    rid = k.post("/api/resumes/upload", files={"file": ("a.docx", mk())}).json()["id"]
    jid = k.post("/api/jobs", json={"title": "Dev", "description": "We need Python, SQL, AWS, Kubernetes and Docker experience for this role."}).json()["id"]
    k.post(f"/api/jobs/{jid}/match?resume_id={rid}")
    gaps = k.get("/api/skill-gaps").json(); assert {g["skill"] for g in gaps} >= {"aws", "kubernetes"}
    q = k.post("/api/interview/questions", json={"resume_id": rid, "job_id": jid}).json()
    assert len(q["questions"]) >= 6 and any("aws" in x.lower() for x in q["questions"])
    good = "At my internship I built a Python script to automate reports, which reduced manual checking by 30% and I learned to test it carefully before handing it to the team. " * 2
    assert k.post("/api/interview/feedback", json={"question": q["questions"][0], "answer": good}).json()["score"] >= 60
    assert k.post("/api/interview/feedback", json={"question": q["questions"][0], "answer": "yes"}).json()["score"] < 40
    assert k.post("/api/applications", json={"company": "Acme", "role": "Dev", "status": "Bogus"}).status_code == 422
    aid = k.post("/api/applications", json={"company": "Acme", "role": "Dev", "resume_id": rid, "job_id": jid}).json()["id"]
    assert k.patch(f"/api/applications/{aid}", json={"status": "Applied"}).status_code == 200
    assert k.get("/api/applications").json()[0]["status"] == "Applied"
    other = TestClient(A.app); other.post("/api/auth/register", json={"name": "G", "email": "g@x.com", "password": "password1"})
    assert other.patch(f"/api/applications/{aid}", json={"status": "Offer"}).status_code == 404
    assert other.post("/api/applications", json={"company": "X", "role": "Y", "resume_id": rid}).status_code == 404
    assert [s["done"] for s in k.get("/api/flow").json()] == [True, True, True, True, False, True, True]
    assert k.delete(f"/api/applications/{aid}").status_code == 204


def test_parser_regressions():
    """Bugs found by running real-world resumes through the parser."""
    p = A.parse(A.clean("Priya Sharma\npriya@x.com (+91) 98765-43210\nGitHub: @priya\nWork Experience\nBuilt tools\nTECHNICAL SKILLS\nPython\nHonors & Awards\nWon a prize\nProject Manager\nLed a team"))
    assert p["phone"].startswith("(+91)") and p["has_profile_link"]
    assert {"experience", "skills", "achievements"} <= set(p["sections"]) and "projects" not in p["sections"]  # 'Project Manager' is a job title, not a heading
    assert A.find_skills("Let us go to the rest of the express lane in spring") == []  # ordinary English words are not skills
    assert A.find_skills("Go (golang), Node.js, Spring Boot and REST APIs") == ["golang", "node", "rest-api", "spring-boot"]
    assert "\xad" not in A.clean("high\xadimpact") and A.is_action("Developed") and A.is_action("Built") and not A.is_action("Responsible")
    ok = A.analyse("Zoë Ünal José naïve résumé " * 60, p, {"tables": 0, "images": 0})
    assert next(c for c in ok["ats_checks"] if "icon" in c["label"])["pass"]  # accented letters are fine
    bad = A.analyse("Phone \u2706 mail \u2709 " * 60, p, {"tables": 0, "images": 0})
    assert not next(c for c in bad["ats_checks"] if "icon" in c["label"])["pass"]

def test_keywords_clean_and_errors():
    k = TestClient(A.app); k.post("/api/auth/register", json={"name": "K", "email": "k@x.com", "password": "password1"})
    rid = k.post("/api/resumes/upload", files={"file": ("a.docx", mk())}).json()["id"]
    jid = k.post("/api/jobs", json={"title": "Dev", "description": "Need CI pipelines. Knowledge of Terraform and Python is a plus. Strong ownership."}).json()["id"]
    m = k.post(f"/api/jobs/{jid}/match?resume_id={rid}").json()
    assert not any(w.endswith(".") for w in m["missing_keywords"] + m["matching_keywords"]) and "plus" not in m["missing_keywords"]
    assert k.post("/api/jobs", json={"title": "", "description": "x"}).status_code == 422
    import fitz
    e = fitz.open(); e.new_page().insert_text((50, 80), "Secret " * 40); b = e.tobytes(encryption=fitz.PDF_ENCRYPT_AES_256, user_pw="pw", owner_pw="pw")
    r = k.post("/api/resumes/upload", files={"file": ("p.pdf", b)}); assert r.status_code == 422 and "password" in r.json()["detail"]
    assert k.post("/api/resumes/upload", files={"file": ("x.pdf", b"not a pdf")}).status_code == 400
    assert k.post("/api/resumes/upload", files={"file": ("big.pdf", b"%PDF-" + b"0" * (6 * 1024 * 1024))}).status_code == 413
